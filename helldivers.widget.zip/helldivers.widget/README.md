# Helldivers 2 Widget for Übersicht

This is a simple widget for [Übersicht](https://tracesof.net/uebersicht/) that displays current major order(s) to track planets' liberation percentage in HELLDIVERS™ 2 Game.

![Screenshot](screenshot.png)

Uses [Helldivers-2/api](https://github.com/helldivers-2/api) to get the current major order(s) and displays them in a widget.

